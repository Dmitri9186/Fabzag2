// ─── Header Scroll ───
const header = document.getElementById('header');
if (header) {
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 10);
  }, { passive: true });
}

// ─── Mobile Menu ───
const mobileBtn = document.getElementById('mobile-btn');
const mobileMenu = document.getElementById('mobile-menu');
if (mobileBtn && mobileMenu) {
  mobileBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
}

// ─── State ───
let activeId = null;
let showAllCalcs = false;

// ─── Render Category Cards ───
function renderCards() {
  const grid = document.getElementById('cat-grid');
  if (!grid) return;

  if (activeId) {
    const product = PRODUCT_DETAILS[activeId];
    if (!product) { activeId = null; renderCards(); return; }

    const cat = CATEGORIES.find(c => c.id === activeId);

    grid.innerHTML = `
      <div class="cat-detail fade-in">
        <div class="cat-detail-banner">
          <img src="${cat ? cat.image : ''}" alt="${product.title}">
          <button class="cat-detail-back" onclick="goBack()">
            ${ICONS_SVG['arrow-left']} Назад
          </button>
          <h2 class="cat-detail-title">${product.title}</h2>
        </div>
        <div class="cat-detail-body">
          <p class="cat-detail-desc">${product.desc}</p>
          <div class="price-header">
            ${ICONS_SVG['file-text']}
            <span>Прайс-лист</span>
          </div>
          <div class="price-list">
            ${product.items.map((item, idx) => `
              <div class="price-row slide-in" style="animation-delay: ${idx * 0.03}s">
                <div class="price-icon">
                  ${getPriceIcon(item.icon)}
                </div>
                <span class="price-name">${item.name}</span>
                <span class="price-unit">${item.unit}</span>
                <span class="price-value">${item.price === 0 ? '—' : item.price.toLocaleString('ru-RU') + ' ₽'}</span>
              </div>
            `).join('')}
          </div>
          <p class="price-note">Цены без НДС. Скидка 5% от 50 000 ₽, 10% от 100 000 ₽.</p>
          <a href="tel:+74951234567" class="btn-primary btn-full price-cta">
            ${ICONS_SVG['phone']} Уточнить цену
          </a>
        </div>
      </div>
    `;
    return;
  }

  grid.innerHTML = CATEGORIES.map((cat, idx) => `
    <button class="cat-card ${cat.cols === 2 ? 'col-span-2' : ''} fade-in" 
            style="animation-delay: ${idx * 0.03}s"
            onclick="openCard(${cat.id})">
      <span class="cat-card-title">${cat.title}</span>
      <div class="cat-card-image">
        <img src="${cat.image}" alt="${cat.title.replace(/\n/g, ' ')}">
      </div>
    </button>
  `).join('');
}

function openCard(id) {
  activeId = id;
  renderCards();
}

function goBack() {
  activeId = null;
  renderCards();
}

// ─── Render Calculators ───
function renderCalculators() {
  const grid = document.getElementById('calc-grid');
  const btn = document.getElementById('calc-toggle');
  if (!grid || !btn) return;

  const visible = showAllCalcs ? CALCULATORS : CALCULATORS.slice(0, 6);

  grid.innerHTML = visible.map(calc => `
    <a href="#" class="calc-item">
      ${getCalcIcon(calc.icon)}
      <span>${calc.label}</span>
    </a>
  `).join('');

  btn.innerHTML = showAllCalcs
    ? `${ICONS_SVG['chevron-up']} Свернуть`
    : `${ICONS_SVG['eye']} Смотреть все`;
}

function toggleCalcs() {
  showAllCalcs = !showAllCalcs;
  renderCalculators();
}

// ─── Init ───
document.addEventListener('DOMContentLoaded', () => {
  renderCards();
  renderCalculators();
});
